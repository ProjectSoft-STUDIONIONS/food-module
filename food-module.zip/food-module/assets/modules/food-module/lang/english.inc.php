<?php
$_lang["sch_file"] = "Файл";
$_lang["sch_permission"] = "Права";
$_lang["sch_file_rename"] = "Файл переименован";
$_lang['sch_file_error_rename'] = "Файл не переименован";
$_lang["sch_files_upload_select"] = "Выберите файлы для загрузки";
$_lang["sch_file_upload"] = "Файл загружен";
$_lang["sch_file_upload_error"] = "Ошибка загрузки";
$_lang["sch_file_notfound"] = "Файл не существует!";
$_lang["sch_file_duble"] = "Файл с этим именем уже существует";
